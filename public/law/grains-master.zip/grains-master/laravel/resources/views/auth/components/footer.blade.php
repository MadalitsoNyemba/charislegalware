<footer class="footer mt-3">
	<div class="container-fluid">
		<div class="footer-content text-center small">
			<span class="text-muted">&copy; {{ date('Y') }} {{ config('app.name', 'Laravel') }}. All Rights Reserved.</span>
		</div>
	</div>
</footer>